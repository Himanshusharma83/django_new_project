from django.contrib import admin
from django.urls import path
from home import views

admin.site.site_header = "Himanshu"
admin.site.site_title = "Himanshu Admin Portal"
admin.site.index_title = "Welcome to Himanshu World Portal"

urlpatterns = [
path("",views.index,name='home'),
path("about",views.about,name='about'),
path("services",views.services,name='services'),
path("contact",views.contact,name='contact'),


]
 